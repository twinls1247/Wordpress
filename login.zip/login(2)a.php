<p align="left"> </p><?php 

$page_title= 'login';

//include('../php/header.html');

//Check if the form has been submitted.
if (isset($_POST['submitted'])) 
 {
	//$errors = arrays(); //initialize error array.
	require_once('mysql_connect.php');  //connect to the db
	
		 		function escape_data($data){
	 			global $dbc;  //Need the connection.
	 			if (ini_get('magic_quotes_gpc')) {
	 			$data = stripslashes($data);
	 			}
	 			return mysql_real_escape_string(trim($data), $dbc);
	 		 }  //end of function
	 		
	//check for Login.
  if(empty($_POST['login'])) 
  {
	$errors[]='Please enter your login';
  }
  else 
  {
	$lg = escape_data($_POST['login']);
  }

  if(empty($_POST['password'])) 
  {
  $errors[]= 'You forgot to enter your password.';
	}
	else 
	{
	$p = escape_data($_POST['password']);
	}

	if (empty($errors)) 
	{ //If everythings okay.	
	 		
		//Register the user in the database.
	  //require_once('mysql_connect.php');  //connect to the db
	 		
	 	//Make the query
	 	$query = "SELECT * FROM shb8_201_1.Users 
	 	WHERE log_In='$lg' AND password=SHA1('$p')";
	 	
		$result = @mysql_query($query); //Run the query.
	if ($result)
	 {
			while 
			    ($row = mysql_fetch_array($result, MYSQL_ASSOC)) 
			{ //if it ran ok
				 
				if ($row['log_In'] == $lg)
				{
				//$errors[]='<h3>login and/or password is incorrect</h3>';
				
						if ($row['password']== sha1($p))
						{

                                           //       session_start();
                                           //      $_SESSION['user_id']= $row['user_id'];
                                           //       $_SESSION['first_name']=$row['first_name'];

						//echo '<h3>You are logged into the database</h3>';   //Print a message
				
						//echo '<h1 id="mainhead">Thankyou!</h1>';
                        //echo '<p><input type=button value="Back to Form" onClick="history.go(-1);" />';
//echo '<h4><b><a href="/kti_portal?id=' . sha1($row['log_In'] ) . ' ">Go To Employee Intranet</a></b></h4></p> ';  
					
               header("Location: /kti_portal") ;
							
							//Include the footer and quit the script
							include 'footer.html';
							exit();
						 }
				 	 }
				  }
				  
				if(empty($row))
				{
					echo '<h3>wrong password and/or login </h3>
					<p><input type=button value="Back to Form" onClick="history.go(-1);"/></p>';
				} 
			}
			
			if(!$query)
			{// If Database did not run OK.
				echo '<h1 id="mainhead">System Error</h1>
				
				<p class="error">You could not be logged in due to a system error. 
				We apologize for any inconvenience.></p>  
				<p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>';  //public message(data base error connection)
				
				echo '<p>' .mysql_error(). '<br /><br />Query:' .$query. '</p>'; //Debugging message.
				include 'footer.html';
				exit();
			}
	
			mysql_close(); //close the database connection.
				
		}
	 
	//	if($errors)
	//	{// If Database did not run OK.
	//			echo '<h1 id="mainhead">System Error</h1>
				
	//			<p class="error">You could not be logged in due to a system error. 
	//			We apologize for any inconvenience.></p>  
	//			<p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>';  //public message(data base error connection)
				
	//			echo '<p>' .mysql_error(). '<br /><br />Query:' .$query. '</p>'; //Debugging message.
	//			include 'footer.html';
	//			exit();
	//	}
	
	//		mysql_close(); //close the database connection.
			
	  
 
else { //Report errors.
			
			echo '<h1 id="meanhead">Error!</h1>
			<p class="error">The following error(s) occurred:<br />';
			foreach($errors as $msg) {//Print each error.
				echo "- $msg<br />\n";
			 }
			echo '</p><p>Please try again.</p>
			<p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>
			<p><br /></p>';
			
		  } //End of if (empty($errors)) IF.
	
 }//End of the main Submit conditional.

?>


<html>
	<head>
		<title>
			Customer Login
		</title>
	</head>
	
	<body>
		
		<h2 align="center">
		<img border="0" src="KTI_cov_pic.jpg" width="480" height="166"></h2>
		<h2 align="center">Employee Login</h2>
		<form action="login(2)a.php" method="POST">
		<blockquote>
			<blockquote>
				<blockquote>
					<blockquote>
						<blockquote>
							<blockquote>
								<blockquote>
									<fieldset>
									<legend>
									<p align="center">Employee Login:</p>
									</legend>
									<table>
										<tr>
											<td>Login:</td>
											<td>
											<input type="text" name="login" size="20" 
		maxlength="20"/></td>
										</tr>
										<tr>
											<td>Password:</td>
											<td>
											<input type="password" name="password" size="20"
		maxlength="20"/></td>
										</tr>
										<tr>
											<td>
											<input type="submit" name="submit" value="Login"/>
											</td>
											<td>
											<input type="reset" name="submit" value="Clear"/>
											</td>
											<td>
											<input type="hidden" name="submitted" value="TRUE"/>
											</td>
										</tr>
									</table></fieldset>
								</blockquote>
							</blockquote>
						</blockquote>
					</blockquote>
				</blockquote>
			</blockquote>
		</blockquote>
		</form>
	
		<!--?php
		//}
		//	include 'footer.html';
		//	exit();
		 ?-->
	<HR> 
		 	 <font face="Times New Roman">�</font> Copyright 2009 <b>
		<font color="#660033">WEB</font><font face="Bodoni MT" color="#669900">TECH</font></b><font face="Bodoni MT">
		</font><font color="#660033">Institute, Inc </font>
	<HR>
		
	</body>
	
</html>