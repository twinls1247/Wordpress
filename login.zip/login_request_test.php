<p align="left"> </p><?php 

$page_title= 'Login Request';

//include('../php/header.html');

//Check if the form has been submitted.
if (isset($_POST['submitted'])) 
 {
	
	//$errors = arrays(); //initialize error array.
	
	//check for name
  if(empty($_POST['name'])) 
  {
	$errors[]='Please enter your name';
   }
  else 
   {
	$nm= trim($_POST['name']))
   }
	
	//check for a first company
  if(empty($_POST['company']))
  {
	$errors[]='Please enter your company';
  }
  else {
	$co = trim($_POST['company']);
  }

//check for a last name.
  if(empty($_POST['industry'])) 
  {
	$errors[]='Please enter your industry';
  }
  else {
	$in = trim($_POST['industry']);
  }

//check for a address.
  if(empty($_POST['address'])) 
  {
	$errors[]='Please enter your address';
  }
  else {
	$addr = trim($_POST['address']);
  }

//check for a city.
  if(empty($_POST['city'])) 
  {
	$errors[]='Please enter your city';
  }
  else {
	$c = trim($_POST['city']);
  }

//check for a state.
  if(empty($_POST['state'])) 
  {
	$errors[]='Please enter your state';
  }
  else {
	$st = trim($_POST['state']);
  }

//check for a zipcode.
  if(empty($_POST['zipcode'])) 
  {
	$errors[]='Please enter your zipcode';
  }
  else {
	$zp = trim($_POST['zipcode']);
  }

//check for a phone.
  if(empty($_POST['phone'])) 
  {
	$errors[]='Please enter your phone number';
  }
  else {
	$ph = trim($_POST['phone']);
  }

//check for email.
  if(empty($_POST['email'])) 
  {
	$errors[]='Please enter your email';
  }
  else {
	$e = trim($_POST['email']);
  }

//check for a web address.
  if(empty($_POST['url'])) 
  {
  	$errors[]= 'You forgot to enter your web address.';
	}
	else 
	 {
	  	$url = trim ($_POST['url']);
	 }
	
	//extract questions field.
	$ques = trim($_POST['questions']);
  
  //extract referral field.
	$ref = trim($_POST['referral']);
	 	
	 	
	 	if (empty($errors)) 
	 	{ //If everythings okay.	
	 		//Register the user in the database.
	 		require_once('mysql_connect.php');  //connect to the db
	 		
	 		//Make the query
	 		$query = "INSERT into shb9_239_1.user (name, company, industry, address, city, state, zip, phone, email, url, questions, referral)
	 		VALUES('$nm', '$co', '$in', '$addr', '$c','$st', '$zp', '$ph', '$e', '$url', $ques, $ref)";
			$result = @mysql_query($query); //Run the query.
			if($result) { //if it ran ok
				
			  echo '<h3>You are now in the database</h3>'; //Print a message
				
				echo '<h1 id="mainhead">Thankyou!</h1>
				<p>You are now registered.</p> <p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>
				<p> <br/> </p>';
				
				//Include the footer and quit the script
				include 'footer.html';
				exit();
				
			} else {// If it did not run OK.
				echo '<h1 id="mainhead">System Error</h1>
				<p class="error">You could not be registered due to a system error. 
				We apologize for any inconvenience.></p>
				<p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>';  //public message
				
				echo '<p>' .mysql_error(). '<br /><br />Query:' .$query. '</p>'; //Debugging message.
				include 'footer.html';
				exit();
			}
			
			mysql_close(); //close the database connection.
			
		 } else { //Report errors.
			
			echo '<h1 id="meanhead">Error!</h1>
			<p class="error">The following error(s) occurred:<br />';
			foreach($errors as $msg) {//Print each error.
				echo "- $msg<br />\n";
			}
			echo '</p><p>Please try again.</p>
			<p><input type=button value="Back to Form" onClick="history.go(-1)"/></p>
			<p><br /></p>';
			
		 } //End of if (empty($errors)) IF.
		
	}//End of the main Submit conditional.
	
?>