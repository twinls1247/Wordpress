<?php
if (!session_id())
	add_action('init', 'session_start');